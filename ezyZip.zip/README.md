# Yasaswini - Frontend Development & Documentation Bot

Status: **Already contributed in source code**

## My part of the project
- `frontend/src/`
- `bots/frontend/frontend_bot.py`
- `bots/documentation/documentation_bot.py`

## My tasks
- [ ] Already contributed in the main source code.
- [ ] Optional: add dashboard screenshots to screenshots/ and a short note on the Documentation Bot.

## Where to put my files
- Notes and write-ups: `team/yasaswini/notes/`
- Screenshots: `team/yasaswini/screenshots/`
- Extra code or demo files (optional): `team/yasaswini/extras/`

Only add files inside `team/yasaswini/`. Do not edit anything outside this folder.
