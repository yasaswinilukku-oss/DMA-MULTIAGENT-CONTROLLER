# Niveditha - Testing Lead & Testing Bot

Status: **Contribution pending**

## My part of the project
- `tests/`
- `bots/testing/testing_bot.py`
- `hardware/testbench/dma_tb.v`

## My tasks
- [ ] Write a short test plan listing what the 29 simulations check.
- [ ] Explain how the bug-injection tests prove the Testing Bot catches bugs.
- [ ] Run `python bots/testing/testing_bot.py` and add a screenshot of the result into screenshots/.
- [ ] Optional: list 3 extra test cases you would add (write them as a list; do not edit tests/ yet).

## Where to put my files
- Notes and write-ups: `team/niveditha/notes/`
- Screenshots: `team/niveditha/screenshots/`
- Extra code or demo files (optional): `team/niveditha/extras/`

Only add files inside `team/niveditha/`. Do not edit anything outside this folder.
